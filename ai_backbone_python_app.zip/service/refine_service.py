# app/service/refine_service.py
from app.model.purifier import refine

# app/service/refine_service.py
from app.model.purifier import refine

def process_prompt(origin_prompt: str, isSlang: bool) -> dict:
    """
    Pchange 값에 따라 모델 실행 여부 분기
    """
    if isSlang:
        revised = refine(origin_prompt)
        return {
            "modifiedPrompt": revised,
            "revised_prompt": revised
        }
    else:
        return {
            "modifiedPrompt": origin_prompt,
            "revised_prompt": origin_prompt
        }

def refine_prompt(prompt: str) -> dict:
    refined = refine(prompt)
    model_used = refined != prompt

    return {
        "original_prompt": prompt,
        "refined_prompt": refined,
        "model_used": model_used,
    }
