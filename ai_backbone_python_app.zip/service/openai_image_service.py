# app/service/openai_image_service.py
from app.core.config import OPENAI_API_KEY
from openai import OpenAI
import logging
from typing import Any, Dict, Optional

logger = logging.getLogger("openai_image_service")
client = OpenAI(api_key=OPENAI_API_KEY)

# -----------------------------
# 2. DALL·E-3 이미지 생성
# -----------------------------
# dalle_result = generate_image(
#     model = IMAGE_MODEL,
#     prompt=final_prompt,
#     size=IMAGE_SIZE,
#     quality=IMAGE_QUALITY,
#     style=IMAGE_STYLE,
# )



def generate_image(
        models: str = "dall-e-3",
        prompt: str = "",
        size: str = "1024x1024",
        quality: str = "standard",
        style: str = "vivid",
) -> Dict[str, Any]:
    """
    ✅ 절대 예외를 밖으로 던지지 않음 (서버가 죽지 않게)
    ✅ 실패 시: image_url=None, revised_prompt=None, error_msg=str(...)
    ✅ 성공 시: image_url=..., revised_prompt(있으면), error_msg=None
    """


    if not prompt or not prompt.strip():
        msg = "prompt is empty"
        logger.warning("[DALL·E] invalid request: %s", msg)
        return {
            "image_url": None,
            "revised_prompt": None,
            "error_msg": msg,
        }

    from openai import BadRequestError
    try:
        # 1. OpenAI API 호출
        resp = client.images.generate(
            model=models,
            prompt=prompt,
            size=size,
            quality=quality,
            style=style,
            n=1,
        )

        # OpenAI Images 응답에서 URL 추출
        image_url = None
        revised_prompt = None
        try:
            image_url = resp.data[0].url
        except (KeyError, IndexError, TypeError):
            image_url = None


        # 일부 응답에 revised_prompt가 있을 수 있으니 안전하게 추출

        if image_url is not None:
            revised_prompt = resp.data[0].revised_prompt


        #raw = resp.model_dump()

        if image_url is None:
            # 이미지 URL이 없으면 성공으로 보기 어려움 → 실패로 처리 + 로그
            msg = "OpenAI response has no image url"

        #    logger.error("[DALL·E] %s | raw=%s", msg, raw)
            print("not images DALL_E")
            return {
                "image_url": None,
                "revised_prompt": None,
                "error_msg": msg,
             }
        #logger.warning("[DALL·E] | raw=%s", raw)


        # 2. 성공 시 필요한 데이터만 뽑아서 딕셔너리로 반환
        # OpenAI 응답 구조: response.data[0].url / response.data[0].revised_prompt
        print("TURE images DALL_E")
        return {
            "image_url": image_url,
            "revised_prompt": resp.data[0].revised_prompt,
            "error_msg": None,
        }

    except BadRequestError as e:
        msg = str(e)

        # 🔴 OpenAI 정책 차단 (의도된 실패)
        if "content_policy_violation" in msg:
            logger.warning("[DALL·E] blocked by content policy | prompt=%s", prompt[:200])
            return {
                "image_url": None,
                "revised_prompt": None,
                "error_msg": "content_policy_violation",
            }

        # 🔴 그 외 예외
        logger.exception(
            "[DALL·E] OpenAI images.generate failed | size=%s quality=%s style=%s prompt=%s",
            size, quality, style, prompt[:200]
        )
        return {
            "image_url": None,
            "revised_prompt": None,
            "error_msg": str(e),
        }
    except Exception as e:
        # 4. 그 외 서버 에러 등
        print(f"이미지 생성 중 알 수 없는 에러: {e}")
        return {
            "image_url": None,
            "revised_prompt": None,
            "error_msg": str(e)
        }
        # # ✅ 여기서 예외를 삼키되, 로그에는 traceback 포함해서 남긴다
        # logger.exception(
        #     "[DALL·E] OpenAI images.generate failed | size=%s quality=%s style=%s prompt=%s",
        #     size, quality, style, prompt[:200]
        # )
        # return {
        # #    "success": False,
        #     "image_url": None,
        #     "revised_prompt": None,
        #     "error_msg": str(e),
        # #    "openai_raw": None,
        # }
