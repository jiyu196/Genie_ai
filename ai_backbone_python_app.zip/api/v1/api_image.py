from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Optional

from app.model.purifier import refine
from app.service.openai_image_service import generate_image
from app.service.translator import translate_to_korean  # ✅ 추가

router = APIRouter()

IMAGE_MODEL = "dall-e-3"
IMAGE_SIZE = "1024x1024"
IMAGE_QUALITY = "standard"
IMAGE_STYLE = "vivid"


# =========================
# Java → Python 요청 DTO
# =========================
class ImageRequest(BaseModel):
    userID: str
    originPrompt: str
    isSlang: bool


# =========================
# Python → Java 응답 DTO
# =========================
class ImageResponse(BaseModel):
    userID: str
    isSlang: bool

    originPrompt: str
    modifiedPrompt: str
    revised_prompt: str

    image_URL: Optional[str] = None
    errorMsg: Optional[str] = None


@router.post("/image/generate", response_model=ImageResponse)
def generate_image_api(req: ImageRequest):

    # -----------------------------
    # 1. 프롬프트 순화 단계
    # -----------------------------
    if req.isSlang:
        purified_prompt = refine(req.originPrompt)
        modified_prompt = purified_prompt
        final_prompt = purified_prompt
    else:
        modified_prompt = req.originPrompt
        final_prompt = req.originPrompt

    # -----------------------------
    # 2. DALL·E-3 이미지 생성
    # -----------------------------
    dalle_result = generate_image(
        models=IMAGE_MODEL,
        prompt=final_prompt,
        size=IMAGE_SIZE,
        quality=IMAGE_QUALITY,
        style=IMAGE_STYLE,
    )

    # ==================================================
    # 🔴 가드 코드 (가장 중요)
    # ==================================================

    # 2-1. OpenAI 정책 차단 (정상적인 실패)
    error_msg = dalle_result.get("error_msg")
    if error_msg == "content_policy_violation":
        return ImageResponse(
            userID=req.userID,
            isSlang=req.isSlang,
            originPrompt=req.originPrompt,
            modifiedPrompt=modified_prompt,
            revised_prompt=translate_to_korean(final_prompt),  # 🔁 함께 번역
            image_URL=None,
            errorMsg="콘텐츠 정책에 위반되어 이미지를 만들지 않습니다.",
        )
        # raise HTTPException(
        #     status_code=422,
        #     detail="이미지 생성 프롬프트가 안전 정책에 의해 차단되었습니다."
        # )

    # 2-2. 기타 이미지 생성 실패
    # 따로 처리해야 할 부분 : 현재까지 발생한 적 없는 예외
    if dalle_result.get("image_url") is None:
        raise HTTPException(
            status_code=500,
            detail=f"이미지 생성 실패: {dalle_result.get('error_msg')}"
        )

    # -----------------------------
    # 3. Java로 내려줄 최종 응답
    #    (성공한 경우에만 도달)
    # -----------------------------
    revised_prompt = dalle_result.get("revised_prompt") or final_prompt
    translated_prompt = translate_to_korean(revised_prompt)
    return ImageResponse(
        userID=req.userID,
        isSlang=req.isSlang,
        originPrompt=req.originPrompt,
        modifiedPrompt=modified_prompt,
        revised_prompt=translated_prompt,
        #image_URL=dalle_result["url"],

        image_URL = dalle_result.get("image_url"),

        errorMsg=None,
    )
#
#     # userID: str
#     # originPrompt: str
#     # Pchange: bool
#     # size: str = "1024x1024"
#     # quality: str = "standard"
#     # style: str = "vivid"
# from fastapi import APIRouter
# from pydantic import BaseModel
# from typing import Optional
#
# from app.model.purifier import refine
# from app.service.openai_image_service import generate_image
#
# router = APIRouter()
#
# IMAGE_MODEL = "dall-e-3"
# IMAGE_SIZE = "1024x1024"
# IMAGE_QUALITY = "standard"
# IMAGE_STYLE = "vivid"
#
# # =========================
# # Java → Python 요청 DTO
# # =========================
# class ImageRequest(BaseModel):
#     userID: str
#     originPrompt: str
#     Pchange: bool
#
#
# # =========================
# # Python → Java 응답 DTO
# # =========================
# class ImageResponse(BaseModel):
#     userID: str
#     Pchange: bool
#
#     originPrompt: str
#     modifiedPrompt: str
#     revised_prompt: str
#
#     image_URL: Optional[str] = None
#     errorMsg: Optional[str] = None
#
#
# @router.post("/image/generate", response_model=ImageResponse)
# def generate_image_api(req: ImageRequest):
#     try:
#         # -----------------------------
#         # 1. 프롬프트 순화 단계
#         # -----------------------------
#         if req.Pchange:
#             purified_prompt = refine(req.originPrompt)
#             modified_prompt = purified_prompt
#             final_prompt = purified_prompt
#         else:
#             modified_prompt = req.originPrompt
#             final_prompt = req.originPrompt
#
#         # -----------------------------
#         # 2. DALL·E-3 이미지 생성
#         # -----------------------------
#         dalle_result = generate_image(
#             models = IMAGE_MODEL,
#             prompt=final_prompt,
#             size=IMAGE_SIZE,
#             quality=IMAGE_QUALITY,
#             style=IMAGE_STYLE,
#         )
#
#         # -----------------------------
#         # 3. Java로 내려줄 최종 응답
#         # -----------------------------
#         return ImageResponse(
#             userID=req.userID,
#             Pchange=req.Pchange,
#             originPrompt=req.originPrompt,
#             modifiedPrompt=modified_prompt,
#             revised_prompt=dalle_result.get("revised_prompt"),
#             image_URL=dalle_result.get("image_url"),
#             errorMsg=dalle_result.get("error_msg"),
#         )
#
#     except Exception as e:
#         return ImageResponse(
#             userID=req.userID,
#             Pchange=req.Pchange,
#             originPrompt=req.originPrompt,
#             modifiedPrompt="",
#             revised_prompt=dalle_result.get("revised_prompt"),
#             image_URL=dalle_result.get("image_url"),
#             errorMsg=dalle_result.get("error_msg"),
#         )
