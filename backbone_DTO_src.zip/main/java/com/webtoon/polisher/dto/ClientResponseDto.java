package com.webtoon.polisher.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Builder;

@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ClientResponseDto {

    private String originalText;        // 입력 원문
    private String ruleFilteredText;     // 규칙 필터 결과
    private String finalPolishedText;    // 최종 결과 (Python)
    private boolean modelUsed;
    private String imageURL;             // 이미지 URL
    private String errorMsg;
}

//package com.webtoon.polisher.dto;
//
//public class ClientResponseDto {
//
//    private String originalText;
//    private String ruleFilteredText;
//    private String finalPolishedText;
//    private boolean modelUsed;
//    private String imageUrl;
//
//    public ClientResponseDto() {
//    }
//
//    public ClientResponseDto(
//            String originalText,
//            String ruleFilteredText,
//            String finalPolishedText,
//            boolean modelUsed,
//            String imageUrl
//    ) {
//        this.originalText = originalText;
//        this.ruleFilteredText = ruleFilteredText;
//        this.finalPolishedText = finalPolishedText;
//        this.modelUsed = modelUsed;
//        this.imageUrl = imageUrl;
//    }
//
//    public String getOriginalText() {
//        return originalText;
//    }
//
//    public String getRuleFilteredText() {
//        return ruleFilteredText;
//    }
//
//    public String getFinalPolishedText() {
//        return finalPolishedText;
//    }
//
//    public boolean isModelUsed() {
//        return modelUsed;
//    }
//
//    public String getImageUrl() {
//        return imageUrl;
//    }
//}
