package com.webtoon.polisher.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;

@Getter
@Setter
@NoArgsConstructor
public class ModelResponseDto {

    private String userID;
    @JsonProperty("isSlang")
    private boolean isSlang;

    private String originPrompt;
    private String modifiedPrompt;

    @JsonProperty("revised_prompt")
    private String revisedPrompt;

    @JsonProperty("image_URL")
    private String imageURL;

    private String errorMsg;
}
