package com.webtoon.polisher.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
@AllArgsConstructor
public class ModelRequestDto {

    private String userID;
    private String originPrompt;
    @JsonProperty("isSlang")
    private boolean isSlang;
}
