// ClientRequestDto.java
package com.webtoon.polisher.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;

@Getter
@Setter
@NoArgsConstructor
public class ClientRequestDto {
    private String userID;
    private String originPrompt;
    private boolean isSlang;
}


//package com.webtoon.polisher.dto;
//
//import jakarta.validation.constraints.Min;
//import jakarta.validation.constraints.NotBlank;
//
//public class ClientRequestDto {
//
//    @NotBlank(message = "사용자 ID는 필수입니다.")
//    private String userId;
//
//    @Min(value = 1, message = "토큰은 최소 1개 이상이어야 합니다.")
//    private int tokenCount;
//
//    @NotBlank(message = "문장은 비어있을 수 없습니다.")
//    @JsonProperty("prompt")
//    private String rawText;
//
//    public String getText() {
//        return rawText;
//    }
//    public void setText(String text) {
//        this.rawText = text;
//    }
//
//}

//package com.webtoon.polisher.dto;
//
///**
// * 클라이언트 → Spring 요청 DTO
// * (웹/프론트에서 들어오는 원문 텍스트)
// */
//public class ClientRequestDto {
//
//    //UserID
//    private String userID;
//
//    // 프론트에서 넘어오는 원문
//    private String originalText;
//
//    private boolean modelUsed;
//
//    // ✅ Lombok 제거 → 기본 생성자 명시
//    public ClientRequestDto() {
//    }
//
//    // (선택) 테스트/내부 사용용 생성자
//    public ClientRequestDto(String text) {
//        this.originalText = text;
//    }
//
//    // ===== Getter / Setter =====
//
//    public String getOriginalText() {
//        return originalText;
//    }
//
//    public void setOriginalText(String text) {
//        this.originalText = text;
//    }
//    public void setUserID(String UserID) {
//        this.userID = UserID;
//    }
//}
