package com.webtoon.polisher.util;

import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.text.Normalizer;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * ✅ 규칙 기반 비속어 필터 (CSV 로딩 + 성능 최적화)
 * - 서버 시작 시 CSV 1회 로딩
 * - 단일 정규식 Pattern
 * - 결과 동일, 성능 대폭 개선
 */
@Slf4j
@Component
public class RuleFilter {

    /** 정규화된 forbidden → clean */
    private final Map<String, String> forbiddenMap = new HashMap<>();

    /** 정규화된 금칙어 Pattern */
    private Pattern forbiddenPattern;

    @PostConstruct
    public void init() {
        log.info("🚀🚀🚀 RULEFILTER INIT START 🚀🚀🚀");
        loadCsv();
        compilePattern();
        //log.info("[RuleFilter] loaded {} forbidden rules", forbiddenMap.size());

        // 처음 20개 규칙 출력
//        log.info("🔍 FIRST 20 LOADED RULES:");
//        forbiddenMap.entrySet().stream().limit(20).forEach(entry ->
//                log.info("   '{}' -> '{}'", entry.getKey(), entry.getValue())
//        );

        log.info("🚀 RULEFILTER INIT COMPLETE 🚀");

        // Pattern 확인
        //log.info("Pattern: {}", forbiddenPattern.pattern());
    }

    /**
     * CSV 파일 로딩 (⭐ 정규화 핵심)
     */
    private void loadCsv() {
        try {
            ClassPathResource resource = new ClassPathResource("forbidden_to_clean.csv");

            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(resource.getInputStream(), StandardCharsets.UTF_8))) {

                String line;
                boolean firstLine = true;

                while ((line = reader.readLine()) != null) {
                    if (firstLine) {
                        firstLine = false;
                        continue;
                    }

                    String[] parts = line.split(",", -1);

                    // 🔥 핵심: 컬럼이 3개인지 2개인지 확인
                    String forbidden;
                    String clean;

                    if (parts.length >= 3) {
                        // index,forbidden,clean 형태
                        forbidden = normalize(parts[1]);
                        clean = parts[2].trim();
                    } else if (parts.length >= 2) {
                        // forbidden,clean 형태
                        forbidden = normalize(parts[0]);
                        clean = parts[1].trim();
                    } else {
                        continue;
                    }

                    if (!forbidden.isEmpty()) {
                        forbiddenMap.put(forbidden, clean.isEmpty() ? " " : clean);
                        //log.debug("Loaded: '{}' -> '{}'", forbidden, clean);
                    }
                }
            }
        } catch (Exception e) {
            log.error("[RuleFilter] CSV loading failed", e);
            throw new IllegalStateException("비속어 CSV 로딩 실패", e);
        }
    }

    /**
     * Pattern 컴파일 (⭐ 정규화된 key 사용)
     */
    private void compilePattern() {
        if (forbiddenMap.isEmpty()) {
            forbiddenPattern = Pattern.compile("(?!x)x");
            return;
        }

        String patternSource = forbiddenMap.keySet().stream()
                .sorted((a, b) -> Integer.compare(b.length(), a.length()))
                .map(Pattern::quote)
                .reduce((a, b) -> a + "|" + b)
                .orElse("");

        forbiddenPattern = Pattern.compile(patternSource);
    }

    /**
     * 규칙 기반 치환 (⭐ 입력도 정규화)
     */
    public String apply(String input) {
        if (input == null || input.isBlank()) {
            return input;
        }

        String normalizedInput = normalize(input);
        log.info("🔍 Original: '{}' | Normalized: '{}'", input, normalizedInput);

        // 디버깅: 매칭 확인
        Matcher matcher = forbiddenPattern.matcher(normalizedInput);
        boolean found = false;
        while (matcher.find()) {
            found = true;
            log.info("✅ MATCHED: '{}' at position {}", matcher.group(), matcher.start());
        }

        if (!found) {
            log.warn("❌ NO MATCH for input: '{}'", normalizedInput);
        }

        // 실제 치환 로직
        matcher.reset();
        StringBuffer sb = new StringBuffer(normalizedInput.length());
        while (matcher.find()) {
            String matched = matcher.group();
            String replacement = forbiddenMap.getOrDefault(matched, matched);
            matcher.appendReplacement(sb, Matcher.quoteReplacement(replacement));
        }
        matcher.appendTail(sb);
        return sb.toString();
    }
//    public String apply(String input) {
//
//        if (input == null || input.isBlank()) {
//            return input;
//        }
//
//        String normalizedInput = normalize(input);
//
//        Matcher matcher = forbiddenPattern.matcher(normalizedInput);
//        StringBuffer sb = new StringBuffer(normalizedInput.length());
//
//        while (matcher.find()) {
//            String matched = matcher.group();
//            String replacement =
//                    forbiddenMap.getOrDefault(matched, matched);
//            matcher.appendReplacement(sb, Matcher.quoteReplacement(replacement));
//        }
//
//        matcher.appendTail(sb);
//        return sb.toString();
//    }

    /**
     * 문자열 정규화 (🔥 핵심 유틸)
     */
    private String normalize(String s) {
        if (s == null) return "";
        return Normalizer.normalize(s, Normalizer.Form.NFC)
                .replaceAll("\\uFEFF", "")   // BOM 제거
                .replaceAll("\\p{Cf}", "")   // zero-width 제거
                .trim();
    }
}

//@Slf4j
//@Component
//public class RuleFilter {
//
//    /** forbidden_word → clean_word */
//    private final Map<String, String> forbiddenMap = new HashMap<>();
//
//    /** 모든 금칙어를 하나의 Pattern으로 컴파일 */
//    private Pattern forbiddenPattern;
//
//    /**
//     * 서버 기동 시 1회 실행
//     */
//    @PostConstruct
//    public void init() {
//        loadCsv();
//        compilePattern();
//        log.info("[RuleFilter] loaded {} forbidden rules", forbiddenMap.size());
//    }
//
//    /**
//     * CSV 파일 로딩
//     */
//    private void loadCsv() {
//        try {
//            ClassPathResource resource =
//                    new ClassPathResource("forbidden_to_clean.csv");
//
//            try (BufferedReader reader = new BufferedReader(
//                    new InputStreamReader(resource.getInputStream(), StandardCharsets.UTF_8))) {
//
//                String line;
//                boolean firstLine = true;
//
//                while ((line = reader.readLine()) != null) {
//                    // 헤더 스킵
//                    if (firstLine) {
//                        firstLine = false;
//                        continue;
//                    }
//
//                    String[] parts = line.split(",", -1);
//                    if (parts.length < 2) continue;
//
//                    String forbidden = parts[0].trim();
//                    String clean = parts[1].trim();
//
//                    if (!forbidden.isEmpty()) {
//                        forbiddenMap.put(forbidden, clean);
//                    }
//                }
//            }
//        } catch (Exception e) {
//            log.error("[RuleFilter] CSV loading failed", e);
//            throw new IllegalStateException("비속어 CSV 로딩 실패", e);
//        }
//    }
//
//    /**
//     * 금칙어 Pattern 컴파일
//     */
//    private void compilePattern() {
//        if (forbiddenMap.isEmpty()) {
//            forbiddenPattern = Pattern.compile("(?!x)x"); // 매칭 안 되는 더미
//            return;
//        }
//
//        String patternSource = forbiddenMap.keySet().stream()
//                // 긴 단어 먼저 (부분 일치 방지)
//                .sorted((a, b) -> Integer.compare(b.length(), a.length()))
//                .map(Pattern::quote)
//                .reduce((a, b) -> a + "|" + b)
//                .orElse("");
//
//        forbiddenPattern = Pattern.compile(patternSource);
//    }
//
//    /**
//     * 규칙 기반 치환 (핵심 메서드)
//     */
//    public String apply(String input) {
//        log.error("🔥 APPLY CALLED");
//        log.error("🔥 INPUT='{}'", input);
//        log.error("🔥 MAP SIZE={}", forbiddenMap.size());
//
//        for (String key : forbiddenMap.keySet()) {
//            if (key.contains("알몸")) {
//                log.error("FOUND KEY='{}'", key);
//            }
//        }
//
//        if (input == null || input.isBlank()) {
//            return input;
//        }
//        Matcher matcher = forbiddenPattern.matcher(input);
//        StringBuffer sb = new StringBuffer(input.length());
//
//        while (matcher.find()) {
//            String matched = matcher.group();
//            String replacement = forbiddenMap.getOrDefault(matched, matched);
//            matcher.appendReplacement(sb, Matcher.quoteReplacement(replacement));
//        }
//
//        matcher.appendTail(sb);
//        return sb.toString();
//    }
//}

//package com.webtoon.polisher.util;
//
//import org.springframework.stereotype.Component;
//
//import jakarta.annotation.PostConstruct;
//import java.io.BufferedReader;
//import java.io.InputStreamReader;
//import java.nio.charset.StandardCharsets;
//import java.util.HashMap;
//import java.util.Map;
//
//@Component
//public class RuleFilter {
//
//    // forbidden -> clean 매핑
//    private final Map<String, String> replaceRules = new HashMap<>();
//
//    /**
//     * 서버 시작 시 한 번 실행
//     * CSV 파일을 읽어 규칙을 메모리에 적재
//     */
//    @PostConstruct
//    public void init() {
//        loadRulesFromCsv("/forbidden_to_clean.csv");
//        System.out.println("[RuleFilter] rules loaded: " + replaceRules.size());
//    }
//
//    /**
//     * CSV 파일 로딩
//     */
//    private void loadRulesFromCsv(String resourcePath) {
//        try (
//                BufferedReader reader = new BufferedReader(
//                        new InputStreamReader(
//                                getClass().getResourceAsStream(resourcePath),
//                                StandardCharsets.UTF_8
//                        )
//                )
//        ) {
//            String line;
//            boolean isHeader = true;
//
//            while ((line = reader.readLine()) != null) {
//                // 헤더 스킵
//                if (isHeader) {
//                    isHeader = false;
//                    continue;
//                }
//
//                String[] parts = line.split(",", -1);
//                if (parts.length < 2) continue;
//
//                String forbidden = parts[0].trim();
//                String clean = parts[1].trim();
//
//                if (forbidden.isEmpty() || clean.isEmpty()) continue;
//
//                replaceRules.put(forbidden, clean);
//            }
//
//        } catch (Exception e) {
//            throw new RuntimeException("[RuleFilter] CSV 로딩 실패", e);
//        }
//    }
//
//    /**
//     * 문장에 규칙 적용
//     */
//    public String filter(String text) {
//        if (text == null) return null;
//
//        String original = text;
//        String result = text;
//        int hit = 0;
//
//        for (Map.Entry<String, String> entry : replaceRules.entrySet()) {
//            if (result.contains(entry.getKey())) {
//                result = result.replace(entry.getKey(), entry.getValue());
//                hit++;
//            }
//        }
//
//        // 로그 출력
//        if (hit > 0) {
//            System.out.println("[RuleFilter] text changed (hit=" + hit + ")");
//            System.out.println("before: " + original);
//            System.out.println("after : " + result);
//        } else {
//            System.out.println("[RuleFilter] no change");
//        }
//
//        return result;
//    }
//}
