package com.webtoon.polisher.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "prompt_history")
public class PromptHistory {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(length = 1000)
    private String originalText;

    @Column(length = 1000)
    private String ruleFilteredText;

    @Column(length = 1000)
    private String finalText;

    private boolean modelUsed;

    public PromptHistory() {
    }

    public PromptHistory(
            String originalText,
            String ruleFilteredText,
            String finalText,
            boolean modelUsed
    ) {
        this.originalText = originalText;
        this.ruleFilteredText = ruleFilteredText;
        this.finalText = finalText;
        this.modelUsed = modelUsed;
    }

    public Long getId() {
        return id;
    }
}
