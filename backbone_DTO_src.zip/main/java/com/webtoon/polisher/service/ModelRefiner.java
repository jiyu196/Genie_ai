package com.webtoon.polisher.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.webtoon.polisher.dto.ModelRequestDto;
import com.webtoon.polisher.dto.ModelResponseDto;
import com.webtoon.polisher.util.RuleFilter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;

@Slf4j
@Service
public class ModelRefiner {

    private final WebClient webClient;
    private final ObjectMapper objectMapper = new ObjectMapper();

    public ModelRefiner(WebClient webClient) {
        this.webClient = webClient;
    }

    public ModelResponseDto refine(
            String userID,
            String originPrompt,
            boolean isSlang
    ) {

        ModelRequestDto requestDto =
                new ModelRequestDto(userID, originPrompt, isSlang);

        // =========================
        // 🔍 Java → Python 요청 로그
        // =========================
        try {
            log.info(
                    "📤 [PYTHON REQUEST]\n{}",
                    objectMapper
                            .writerWithDefaultPrettyPrinter()
                            .writeValueAsString(requestDto)
            );
        } catch (Exception e) {
            log.warn("요청 JSON 로그 출력 실패", e);
        }

        try {
            // =========================
            // 정상 호출
            // =========================
            ModelResponseDto response = webClient.post()
                    .uri("http://localhost:8000/api/v1/image/generate")
                    .contentType(MediaType.APPLICATION_JSON)
                    .bodyValue(requestDto)
                    .retrieve()
                    .bodyToMono(ModelResponseDto.class)
                    .block();

            log.info("📥 [PYTHON RESPONSE] success");
            return response;

        } catch (WebClientResponseException e) {

            // =========================
            // 🔥 Python 오류 응답 처리
            // =========================
            log.error("❌ Python error status={}", e.getStatusCode());
            log.error("❌ Python error body={}", e.getResponseBodyAsString());

            ModelResponseDto errorResponse = new ModelResponseDto();
            errorResponse.setUserID(userID);
            errorResponse.setSlang(isSlang);
            errorResponse.setOriginPrompt(originPrompt);
            errorResponse.setModifiedPrompt(originPrompt);
            errorResponse.setErrorMsg("Python AI 서버 오류: " + e.getStatusCode());

            return errorResponse;

        } catch (Exception e) {

            // =========================
            // 기타 예외
            // =========================
            log.error("❌ Python 호출 실패", e);

            ModelResponseDto errorResponse = new ModelResponseDto();
            errorResponse.setUserID(userID);
            errorResponse.setSlang(isSlang);
            errorResponse.setOriginPrompt(originPrompt);
            errorResponse.setModifiedPrompt(originPrompt);
            errorResponse.setErrorMsg("AI 서버 응답이 없습니다.");

            return errorResponse;
        }
    }
}




//@Slf4j
//@Service
//public class ModelRefiner {
//
//    private final WebClient webClient;
//
//    // ✅ [추가] objectMapper 선언 (기능 변경 없음)
//    private final ObjectMapper objectMapper = new ObjectMapper();
//
//    public ModelRefiner(WebClient webClient) {
//        this.webClient = webClient;
//    }
//
//    public ModelResponseDto refine(
//            String userID,
//            String originPrompt,
//            boolean pChange
//    ) {
//
//        // =========================
//        // 기존 DTO 생성 로직 (유지)
//        // =========================
//        ModelRequestDto requestDto =
//                new ModelRequestDto(userID, originPrompt, pChange);
//
//        // =========================
//        // ✅ [추가] 요청 JSON 로그 (기능 영향 없음)
//        // =========================
//        try {
//            String json = objectMapper
//                    .writerWithDefaultPrettyPrinter()
//                    .writeValueAsString(requestDto);
//
//            log.info("📤 [PYTHON REQUEST JSON]\n{}", json);
//
//        } catch (Exception e) {
//            log.warn("요청 JSON 로그 출력 실패", e);
//        }
//
//        // =========================
//        // 기존 Python 호출 로직 (유지)
//        // =========================
//        try {
//            return webClient.post()
//                    .uri("http://localhost:8000/api/v1/image/generate")
//                    .contentType(MediaType.APPLICATION_JSON)
//                    .bodyValue(requestDto)
//                    .retrieve()
//                    .bodyToMono(ModelResponseDto.class)
//                    .block();
//
//        } catch (WebClientResponseException e) {
//
//            // 기존 예외 처리 유지 + 로그만 보강
//            log.error("❌ Python 서버 오류 status={}", e.getStatusCode());
//            log.error("❌ Python 응답 body={}", e.getResponseBodyAsString());
//
//            throw e;
//        }
//    }
//}
