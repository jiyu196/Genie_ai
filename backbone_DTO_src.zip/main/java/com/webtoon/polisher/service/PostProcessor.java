package com.webtoon.polisher.service;

import org.springframework.stereotype.Component;

@Component
public class PostProcessor {

    public String process(String text) {
        if (text == null || text.isBlank()) return " ";

        // ① dummy 토큰 제거
        text = text.replace("그그그", "")
                .replace("으으", "");

        // ② 첫 마침표 이전만 유지
        int idx = text.indexOf(".");
        if (idx != -1) {
            text = text.substring(0, idx);
        }

        return text;
    }
}
