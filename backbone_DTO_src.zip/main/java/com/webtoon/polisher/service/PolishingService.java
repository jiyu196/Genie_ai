package com.webtoon.polisher.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.webtoon.polisher.dto.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;


import com.webtoon.polisher.util.RuleFilter;
/**
 * ✔ 규칙 기반 비속어 필터링 유지
 * ✔ Python FastAPI 연동
 * ✔ Lombok @Slf4j 로깅
 */
@Slf4j
@Service
public class PolishingService {

    private final WebClient webClient;
    private final RuleFilter ruleFilter;   // ✅ 기존 규칙 필터

    @Value("${model.server.url}")
    private String modelServerUrl;

    public PolishingService(
            WebClient webClient,
            RuleFilter ruleFilter
    ) {
        this.webClient = webClient;
        this.ruleFilter = ruleFilter;
    }

    /**
     * Controller에서 호출되는 핵심 진입점
     */
    public ClientResponseDto polish(ClientRequestDto request) {

        log.info("[SERVICE] polish start | isSlang={}", request.isSlang());

        // ==================================================
        // 1️⃣ 규칙 기반 비속어 필터링 (기존 로직 유지)
        // ==================================================
        String originalText = request.getOriginPrompt();
        String ruleFilteredText = ruleFilter.apply(originalText);

        log.debug("[RULE_FILTER] before='{}'", originalText);
        log.debug("[RULE_FILTER] after ='{}'", ruleFilteredText);

        // 1️⃣-1️⃣ pChange 계산 (⭐ 핵심)
        boolean p_change = !originalText.equals(ruleFilteredText);


        // ==================================================
        // 2️⃣ Python 서버로 보낼 요청 DTO
        // ==================================================
        ModelRequestDto modelRequest = new ModelRequestDto(
                request.getUserID(),
                ruleFilteredText,
                p_change
        );
        // 🔥 추가: JSON 직렬화 확인
        try {
            ObjectMapper mapper = new ObjectMapper();
            String jsonRequest = mapper.writeValueAsString(modelRequest);
            log.info("📤 SENDING JSON TO PYTHON: {}", jsonRequest);
        } catch (Exception e) {
            log.error("JSON serialization failed", e);
        }

        log.info("🚀 CALLING PYTHON SERVER");
        log.info("   URL: {}", modelServerUrl);

        try {
            // ==================================================
            // 3️⃣ Python FastAPI 호출
            // ==================================================
            ModelResponseDto modelResponse =
                    webClient.post()
                            .uri(modelServerUrl)
                            .bodyValue(modelRequest)
                            .retrieve()
                            .bodyToMono(ModelResponseDto.class)
                            .onErrorResume(e -> {
                                log.error("[PYTHON_CALL_ERROR]", e);
                                return Mono.empty();
                            })
                            .block();

            // ==================================================
            // 4️⃣ Python 서버 응답 없음
            // ==================================================
            if (modelResponse == null) {
                log.warn("[PYTHON_RESPONSE_NULL]");

                return ClientResponseDto.builder()
                        .originalText(originalText)
                        .ruleFilteredText(ruleFilteredText)
                        .finalPolishedText(ruleFilteredText)
                        .modelUsed(false)
                        .errorMsg("AI 서버 응답이 없습니다.")
                        .build();
            }

            // ==================================================
            // 5️⃣ Python 서버 에러 반환
            // ==================================================
            if (modelResponse.getErrorMsg() != null) {
                log.warn("[PYTHON_ERROR] {}", modelResponse.getErrorMsg());

                return ClientResponseDto.builder()
                        .originalText(modelResponse.getOriginPrompt())
                        .ruleFilteredText(modelResponse.getModifiedPrompt())
                        .finalPolishedText(modelResponse.getRevisedPrompt())
                        .modelUsed(false)
                        .errorMsg(modelResponse.getErrorMsg())
                        .build();
            }

            // ==================================================
            // 6️⃣ 정상 성공
            // ==================================================
            log.info(
                    "[POLISH_SUCCESS] modelUsed={} | URL='{}'",
                    modelResponse.isSlang(),
                    modelResponse.getImageURL()
            );

            return ClientResponseDto.builder()
                    .originalText(modelResponse.getOriginPrompt())
                    .ruleFilteredText(modelResponse.getModifiedPrompt())
                    .finalPolishedText(modelResponse.getRevisedPrompt())
                    .modelUsed(modelResponse.isSlang())
                    // 👇👇👇 여기가 추가된 핵심 코드입니다 👇👇👇
                    .imageURL(modelResponse.getImageURL())
                    .errorMsg(null)
                    .build();

        } catch (Exception e) {
            log.error("[SERVICE_EXCEPTION]", e);

            return ClientResponseDto.builder()
                    .originalText(originalText)
                    .ruleFilteredText(ruleFilteredText)
                    .finalPolishedText(ruleFilteredText)
                    .modelUsed(false)
                    .errorMsg("AI 처리 중 서버 오류가 발생했습니다.")
                    .build();
        }
    }
}
