//WebtoonController.java
package com.webtoon.polisher.controller;

import com.webtoon.polisher.dto.ClientRequestDto;
import com.webtoon.polisher.dto.ClientResponseDto;
import com.webtoon.polisher.service.PolishingService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/api/webtoon")
@RequiredArgsConstructor
@Slf4j
public class WebtoonController {

    private final PolishingService polishingService;

    @PostMapping(
            value = "/refine",
            consumes = "application/json",
            produces = "application/json"
    )
    public ClientResponseDto refine(@RequestBody ClientRequestDto request) {

        if (request.getOriginPrompt() == null || request.getOriginPrompt().isBlank()) {
            log.warn("[REQUEST_INVALID] originPrompt is null or blank");
            throw new IllegalArgumentException("originPrompt is required");
        }

        log.info(
                "[REQUEST_RECEIVED] userID={} | originPrompt='{}'",
                request.getUserID(),
                request.getOriginPrompt()
        );

        return polishingService.polish(request);
    }
}

//public class WebtoonController {
//
//    private final PolishingService polishingService;
//
//    @PostMapping("/refine")
//    public ClientResponseDto refine(@RequestBody ClientRequestDto request) {
//        log.info("[REQUEST] originPrompt={}", request.getOriginPrompt());
//        return polishingService.polish(request);
//    }
//}


//@RestController
//@RequestMapping("/api/webtoon")
//public class WebtoonController {
//
//    private static final Logger log =
//            LoggerFactory.getLogger(WebtoonController.class);
//
//    private final PolishingService polishingService;
//
//    public WebtoonController(PolishingService polishingService) {
//        this.polishingService = polishingService;
//    }
//
//    @PostMapping("/refine")
//    public ClientResponseDto refine(@RequestBody ClientRequestDto request) {
//
//        log.info("[REFINE_REQUEST] originPrompt='{}', Pchange={}",
//                request.getText(),
//                request.isPchange()
//        );
//
//        // 🔥 Python 이미지 서버까지 포함된 서비스 호출
//        ClientResponseDto response = polishingService.polish(request);
//
//        log.info(
//                "[REFINE_RESULT] imageUrl={}, errorMsg={}",
//                response.getImageUrl(),
//                response.getErrorMsg()
//        );
//
//        return response;
//    }
//}

//@RestController
//@RequestMapping("/api/webtoon")
//@RequiredArgsConstructor
//@CrossOrigin(origins = "http://localhost:3000") // React 개발 서버 허용
//@CrossOrigin(origins = "http://localhost:5000") // React 개발 서버 허용
//public class PromptController {
//
//    private final WebtoonPolishingService polishingService;
//    private final HistoryRepository historyRepository;
//
//    @PostMapping("/refine")
//    public ResponseEntity<ClientResponseDto> refinePrompt(@RequestBody ClientRequestDto request) {
//
//        System.out.println("Input Received: " + request.toString());
//
//        // 1. 서비스 호출 (필터링 -> 모델 전송 -> 순화된 결과 획득)
//        String filteredText = polishingService.filterText(request.getRawText());
//        String polishedText = polishingService.processSentence(
//                request.getUserId(),
//                request.getTokenCount(),
//                request.getRawText()
//        );
//
//        // 2. DB 저장 (Storage)
//        PromptHistory history = new PromptHistory();
//        history.setUserId(request.getUserId());
//        history.setOriginalText(request.getRawText());
//        history.setFilteredText(filteredText);
//        history.setPolishedText(polishedText);
//        history.setCreatedAt(LocalDateTime.now());
//
//        historyRepository.save(history);
//
//        // 3. Client 응답 (Response)
//        ClientResponseDto response = new ClientResponseDto(
//                request.getRawText(),
//                filteredText,
//                polishedText,
//                "성공적으로 변환되었습니다."
//        );
//
//        return ResponseEntity.ok(response);
//    }
//}