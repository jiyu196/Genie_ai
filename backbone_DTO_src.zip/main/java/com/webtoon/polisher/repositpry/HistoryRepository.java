package com.webtoon.polisher.repository;

import com.webtoon.polisher.entity.PromptHistory;
import org.springframework.data.jpa.repository.JpaRepository;

public interface HistoryRepository
        extends JpaRepository<PromptHistory, Long> {
}
